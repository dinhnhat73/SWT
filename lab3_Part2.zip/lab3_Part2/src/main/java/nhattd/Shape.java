package nhattd;

public class Shape {
}
