package nhattd;

import java.io.*;
import java.util.logging.*;

public class PathTraversalExample {
    private static final Logger logger = Logger.getLogger(PathTraversalExample.class.getName());

    public static void main(String[] args) throws IOException {
        String baseDir = "data"; // thư mục cố định
        String userInput = "input.txt"; // giả lập đầu vào hợp lệ

        File file = new File(baseDir, userInput).getCanonicalFile();
        File safeDir = new File(baseDir).getCanonicalFile();

        if (!file.getPath().startsWith(safeDir.getPath())) {
            throw new SecurityException("Attempt to access file outside allowed directory!");
        }

        if (file.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                logger.info("Reading file: " + file.getPath());
                String line;
                while ((line = reader.readLine()) != null) {
                    logger.info(line);
                }
            }
        } else {
            logger.warning("File not found.");
        }
    }
}
