package nhattd;

interface LoginHandler {
    boolean login(String username, String password);
}