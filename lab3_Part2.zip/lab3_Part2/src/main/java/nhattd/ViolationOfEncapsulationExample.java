package nhattd;

public class ViolationOfEncapsulationExample {
    private final String name;
    private final int age;

    public ViolationOfEncapsulationExample(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public int getAge() {
        return age;
    }

    public void display() {
        // System.out.println("Name: " + name + ", Age: " + age); // not recommended
        java.util.logging.Logger logger = java.util.logging.Logger.getLogger(getClass().getName());
        logger.info("Name: " + name + ", Age: " + age);
    }

    public static void main(String[] args) {
        ViolationOfEncapsulationExample user = new ViolationOfEncapsulationExample("Nhat", 20);
        user.display();
    }
}
