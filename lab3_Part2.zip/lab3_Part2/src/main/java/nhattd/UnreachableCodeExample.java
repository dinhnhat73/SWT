package nhattd;

public class UnreachableCodeExample {

    public static int getNumber() {
        // In thông báo trước khi trả về giá trị
        System.out.println("Returning number...");
        return 42;
    }

    public static void main(String[] args) {
        System.out.println(getNumber());
    }
}
