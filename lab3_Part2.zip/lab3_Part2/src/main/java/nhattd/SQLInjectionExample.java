package nhattd;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SQLInjectionExample {

    // Tạo logger
    private static final Logger LOGGER = Logger.getLogger(SQLInjectionExample.class.getName());

    public static void main(String[] args) {
        // Giả lập đầu vào người dùng nguy hiểm
        String userInput = "' OR '1'='1";

        // Đọc thông tin kết nối từ biến môi trường (hoặc file cấu hình)
        String url = System.getenv("DB_URL");          // ví dụ: jdbc:mysql://localhost:3306/mydb
        String username = System.getenv("DB_USER");    // ví dụ: root
        String password = System.getenv("DB_PASS");    // ví dụ: 123456

        // Kiểm tra biến môi trường (giả sử bạn chưa cấu hình chúng)
        if (url == null || username == null || password == null) {
            LOGGER.severe("⚠ Cấu hình kết nối chưa được thiết lập trong biến môi trường!");
            return;
        }

        String query = "SELECT username FROM users WHERE username = ?";

        try (
                Connection conn = DriverManager.getConnection(url, username, password);
                PreparedStatement stmt = conn.prepareStatement(query)
        ) {
            stmt.setString(1, userInput);
            LOGGER.info("Thực hiện truy vấn một cách an toàn với PreparedStatement.");

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    LOGGER.info("Tìm thấy người dùng: " + rs.getString("username"));
                }
            }

        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Lỗi kết nối hoặc truy vấn SQL", e);
        }
    }
}
