// File: IncompleteInterfaceImplementationExample.java
package nhattd;

public class IncompleteInterfaceImplementationExample {

    @Override
    public void draw() {
        System.out.println("Drawing shape");
    }

    @Override
    public void resize() {
        System.out.println("Resizing shape");
    }

    public static void main(String[] args) {
        Shape shape = new IncompleteInterfaceImplementationExample();
        shape.draw();
        shape.resize();
    }
}
