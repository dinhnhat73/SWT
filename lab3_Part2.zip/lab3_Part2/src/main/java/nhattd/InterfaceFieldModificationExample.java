package nhattd;

import java.util.logging.Logger;

// Interface definition
interface Drawable {
    void draw();
}

// Class with a unique name, implementing Drawable
class CircleDrawable implements Drawable {
    private static final Logger logger = Logger.getLogger(CircleDrawable.class.getName());

    @Override
    public void draw() {
        logger.info("Drawing a circle.");
    }
}

// Main class to test the implementation
public class UnimplementedInterfaceExample {
    public static void main(String[] args) {
        Drawable shape = new CircleDrawable();
        shape.draw();
    }
}
