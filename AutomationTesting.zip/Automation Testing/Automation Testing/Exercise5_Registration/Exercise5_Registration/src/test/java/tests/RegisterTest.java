package tests;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.Order;  // Quan trọng phải import @Order
import pages.RegisterPage;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@DisplayName("Registration Form Tests with POM")
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class RegisterTest extends BaseTest {

    private RegisterPage registerPage;

    @BeforeAll
    void setupPage() {
        registerPage = new RegisterPage(driver);
    }

    @Test
    @Order(1)
    @DisplayName("Submit with valid required fields")
    public void shouldSubmitWithValidInput() {
        registerPage.navigate();
        registerPage.fillBasicInfo("John", "Doe", "john.doe@example.com", "0912345678");
        registerPage.submit();

        // Chờ modal hiện ra
        assertTrue(registerPage.isSubmitted(), "Modal should appear");
        assertEquals("Thanks for submitting the form", registerPage.getConfirmationTitle());
    }

    @Test
    @Order(2)
    @DisplayName("Submit with empty name fields")
    public void shouldNotSubmitWithEmptyName() {
        registerPage.navigate();
        registerPage.fillBasicInfo("", "", "jane@example.com", "0987654321");
        registerPage.submit();

        // Form không submit được, modal không xuất hiện
        assertFalse(registerPage.isSubmitted(), "Modal should NOT appear with empty name");
    }

    @Test
    @Order(3)
    @DisplayName("Submit with invalid phone number")
    public void shouldNotSubmitWithInvalidPhone() {
        registerPage.navigate();
        registerPage.fillBasicInfo("Jane", "Smith", "jane.smith@example.com", "abc123");
        registerPage.submit();

        // Form không submit được, modal không xuất hiện
        assertFalse(registerPage.isSubmitted(), "Modal should NOT appear with invalid phone");
    }
}
