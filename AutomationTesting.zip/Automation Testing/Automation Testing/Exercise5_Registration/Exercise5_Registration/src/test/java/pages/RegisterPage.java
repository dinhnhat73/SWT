package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class RegisterPage extends BasePage {

    public RegisterPage(WebDriver driver) {
        super(driver);
    }

    // Locators
    private final By firstName = By.id("firstName");
    private final By lastName = By.id("lastName");
    private final By email = By.id("userEmail");
    private final By genderMale = By.xpath("//label[text()='Male']");
    private final By phone = By.id("userNumber");
    private final By submitBtn = By.id("submit");
    private final By resultTitle = By.id("example-modal-sizes-title-lg");

    // Navigate to form page
    public void navigate() {
        driver.get("https://demoqa.com/automation-practice-form");
    }

    // Fill required fields only
    public void fillBasicInfo(String fName, String lName, String mail, String phoneNumber) {
        type(firstName, fName);
        type(lastName, lName);
        type(email, mail);

        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.findElement(genderMale));
        click(genderMale);

        type(phone, phoneNumber);
    }

    // Submit the form
    public void submit() {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", driver.findElement(submitBtn));
        click(submitBtn);
    }

    // Check if submission modal appears
    public boolean isSubmitted() {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(resultTitle));
            return true;
        } catch (TimeoutException e) {
            return false;
        }
    }

    public String getConfirmationTitle() {
        return getText(resultTitle);
    }
}
